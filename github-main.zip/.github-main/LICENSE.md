This license is subjected to change

# CC BY-NC-SA 4.0
**Attribution-NonCommercial-ShareAlike 4.0 International**

This license requires that reusers give credit to the creator. It allows reusers to distribute, remix, adapt, and build upon the material in any medium or format, for noncommercial purposes only. If others modify or adapt the material, they must license the modified material under identical terms.

[8-Bit University](https://github.com/8bituniversity) © 2023 by [Roselle Carmen](https://github.com/aninternetian) is licensed under [CC BY-NC-SA 4.0 ](http://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1)
