This will be the go-to for community health file and other interactions

**TODOS**
- License
- Contributing
- Funding
- Issue and pull request templates
- Code of conduct/Academic honesty

More will be added as we grow

Referenced from [community health file](https://docs.github.com/en/communities/setting-up-your-project-for-healthy-contributions/creating-a-default-community-health-file)
